package com.example.lab3_1_1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private EditText txtNumber;
    private Spinner spnUnits;
    private TextView[] lblResults;
    private String[] units = {
            "Hải lý", "Dặm", "Km","Lý","Met","Yard","Foot","Inch"
    };

    private double[][] ratio = {
            {1, 1.15077945, 1.852, 20.2537183, 1852, 2025.37183, 6076.11549, 72913.38583},
            {0.86897624, 1, 1.609344, 17.6, 1609.344, 1760, 5280, 63360},
            {0.53995680, 0.62137119, 1, 10.936133, 1000, 1093.61330, 3280.83990, 39370.07874},
            {0.04937365, 0.05681818, 0.09144, 1, 91.44, 100, 300, 3600},
            {0.00053996, 0.00062137, 0.001, 0.0109361, 1, 1.09361, 3.28084, 39.37008},
            {0.00049374, 0.00056818, 0.0009144, 0.01, 0.9144, 1, 3, 36},
            {0.00016458, 0.00018939, 0.0003048, 0.0033333, 0.3048, 0.33333, 1, 12},
            {0.00001371, 0.00001578, 0.0000254, 0.0002778, 0.0254, 0.02778, 0.08333, 1}
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNumber = (EditText) findViewById(R.id.txtNumber);
        spnUnits = (Spinner) findViewById(R.id.spnUnit);

        lblResults = new TextView[]{
                (TextView) findViewById(R.id.lblNauticalMile),
                (TextView) findViewById(R.id.lblMile),
                (TextView) findViewById(R.id.lblKilometer),
                (TextView) findViewById(R.id.lblLi),
                (TextView) findViewById(R.id.lblMeter),
                (TextView) findViewById(R.id.lblYard),
                (TextView) findViewById(R.id.lblFoot),
                (TextView) findViewById(R.id.lblInch)
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnits.setAdapter(adapter);

        spnUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                changeLengthUnit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) { }
        });


        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                changeLengthUnit();
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) { }

            @Override
            public void afterTextChanged(Editable arg0) { }
        });
    }
    private void changeLengthUnit() {
        int rowIdx = spnUnits.getSelectedItemPosition();

        if (rowIdx < 0) rowIdx = 0;

        String input = txtNumber.getText().toString();

        if (input.isEmpty()) {
            input = "0";
        }
        if (input.equals(".")) {
            input = "0.";
        }

        double number = 0;
        try {
            number = Double.valueOf(input);
        } catch (NumberFormatException e) {
            number = 0;
        }

        for (int i = 0; i < lblResults.length; i++) {
            double temp = number * ratio[rowIdx][i];
            lblResults[i].setText(String.valueOf(temp));
        }
    }

}