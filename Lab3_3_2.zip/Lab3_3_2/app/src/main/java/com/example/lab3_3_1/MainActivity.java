package com.example.lab3_3_1;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.lab3_3_1.R;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lvMain;
    ArrayList<Product> productList;
    MyListViewAdapter adapter;
    String[] titles = new String[]{
            "Hamburger", "Bánh mì", "Bánh bao", "Bánh ú", "Bánh giò chay", "Bánh giò nhân thịt"
    };

    String[] descriptions = new String[]{
            "Bánh mì kẹp thịt tròn", "Bánh mì kẹp thịt", "Bánh bao nhân thịt, trứng",
            "Bánh ú dùng cho tết, lễ", "Bánh giò chay bằng nếp hoặc tẻ", "Bánh giò nếp, tẻ có nhân thịt"
    };

    String[] prices = new String[]{
            "Giá: 12.000đ", "Giá: 10.000đ", "Giá: 12.000đ",
            "Giá: 5.000đ", "Giá: 5.000đ", "Giá: 8.000đ"
    };
    int[] imgs = new int[]{
            R.drawable.hamburger, R.drawable.banhmi, R.drawable.banhbao,
            R.drawable.banhu, R.drawable.banhgiochay, R.drawable.banhgionhan
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvMain = findViewById(R.id.lvMain);
        productList = new ArrayList<>();
        for (int i = 0; i < titles.length; i++) {
            productList.add(new Product(imgs[i], titles[i], descriptions[i], prices[i]));
        }

        adapter = new MyListViewAdapter(this, productList);
        lvMain.setAdapter(adapter);

        lvMain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Product selectedProduct = productList.get(position);
            }
        });
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_add) {
            Toast.makeText(this, "Click Thêm mới", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menu_exit) {
            finish();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }


}