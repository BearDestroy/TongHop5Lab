package com.example.lab3_3_1;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast; // Thêm để xử lý click

import com.example.lab3_3_1.Product;
import com.example.lab3_3_1.R;

import java.util.ArrayList;

public class MyListViewAdapter extends BaseAdapter {

    Context context;
    ArrayList<Product> list;

    public MyListViewAdapter(Context context, ArrayList<Product> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        ImageView imgFood;
        TextView txtTitle;
        TextView txtDescription;
        TextView txtPrice;
        ImageButton btnEdit;
        ImageButton btnDelete;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = inflater.inflate(R.layout.row, null);

            holder = new ViewHolder();
            holder.imgFood = (ImageView) convertView.findViewById(R.id.imgFood);
            holder.txtTitle = (TextView) convertView.findViewById(R.id.txtTitle);
            holder.txtDescription = (TextView) convertView.findViewById(R.id.txtDescription);
            holder.txtPrice = (TextView) convertView.findViewById(R.id.txtPrice);
            holder.btnEdit = (ImageButton) convertView.findViewById(R.id.btnEdit);
            holder.btnDelete = (ImageButton) convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Product product = list.get(position);

        // Gán dữ liệu lên các view
        holder.imgFood.setImageResource(product.getImage());
        holder.txtTitle.setText(product.getTitle());
        holder.txtDescription.setText(product.getDescription());
        holder.txtPrice.setText(product.getPrice());

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return convertView;
    }
}