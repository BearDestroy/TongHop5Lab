package com.example.lab3_3_1;


public class Product {
    int image;
    String title;
    String description;
    String price;

    public Product(int image, String title, String description, String price) {
        this.image = image;
        this.title = title;
        this.description = description;
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getPrice() {
        return price;
    }
}
