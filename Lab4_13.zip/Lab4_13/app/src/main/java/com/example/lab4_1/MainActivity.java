package com.example.lab4_1;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showFrg(new M000SplashFrg());
    }

    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null)
                .addToBackStack(null)
                .commit();
    }

    public void gotoM001Screen() {
        getSupportFragmentManager().popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
        showFrg(new M001MenuFrg());
    }

    public void gotoM002Screen(String name, String content, String imageFile) {
        M002DetailFrg frg = new M002DetailFrg();
        frg.setData(name, content, imageFile);
        showFrg(frg);
    }
    public void backToMenu() {
        getSupportFragmentManager().popBackStack();
    }
}