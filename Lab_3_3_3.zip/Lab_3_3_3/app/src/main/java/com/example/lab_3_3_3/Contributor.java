package com.example.lab_3_3_3;

public class Contributor {
    private int imageResId;
    private String name;
    private String points;

    public Contributor(int imageResId, String name, String points) {
        this.imageResId = imageResId;
        this.name = name;
        this.points = points;
    }

    // Getters
    public int getImageResId() {
        return imageResId;
    }

    public String getName() {
        return name;
    }

    public String getPoints() {
        return points;
    }
}
