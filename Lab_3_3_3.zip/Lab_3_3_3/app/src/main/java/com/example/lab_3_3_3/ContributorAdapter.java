package com.example.lab_3_3_3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ContributorAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Contributor> contributors;

    public ContributorAdapter(Context context, ArrayList<Contributor> contributors) {
        this.context = context;
        this.contributors = contributors;
    }

    @Override
    public int getCount() {
        return contributors.size();
    }

    @Override
    public Object getItem(int position) {
        return contributors.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        ImageView imageView;
        TextView nameTextView;
        TextView pointsTextView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.grid_item_contributor, parent, false);

            holder = new ViewHolder();
            holder.imageView = convertView.findViewById(R.id.contributor_image);
            holder.nameTextView = convertView.findViewById(R.id.contributor_name);
            holder.pointsTextView = convertView.findViewById(R.id.contributor_points);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Contributor contributor = contributors.get(position);
        holder.imageView.setImageResource(contributor.getImageResId());
        holder.nameTextView.setText(contributor.getName());
        holder.pointsTextView.setText(contributor.getPoints());

        return convertView;
    }
}