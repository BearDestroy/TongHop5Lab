package com.example.lab_3_3_3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private GridView contributorsGrid;
    private ContributorAdapter adapter;
    private ArrayList<Contributor> contributorList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contributorsGrid = findViewById(R.id.contributors_grid);

        contributorList = new ArrayList<>();

        contributorList.add(new Contributor(android.R.drawable.ic_menu_gallery, "Maboo", "283,297"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_camera, "SameOldShawn", "252,433"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_search, "Magnitude901", "164,935"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_info_details, "Brandon", "100,466"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_crop, "Clement_RGF", "93,932"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_compass, "Nebja", "84,187"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_call, "BBDS", "81,762"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_day, "PleaseDe-ModMe", "79,243"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_recent_history, "DLizzle", "76,331"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_rotate, "palacelight", "75,497"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_revert, "TheDarkKnight", "69,138"));
        contributorList.add(new Contributor(android.R.drawable.ic_menu_report_image, "hellrel", "68,903"));
        adapter = new ContributorAdapter(this, contributorList);

        contributorsGrid.setAdapter(adapter);

        contributorsGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Contributor selectedContributor = contributorList.get(position);
                Toast.makeText(MainActivity.this, "Bạn đã chọn: " + selectedContributor.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}